fmatg_f <-
function(param, Lf) {

  gf <- param$g[1:(Lf + 1)]
  
  u <- Lf
  g <- gf
  z1 <- cbind(diag(g[1:u]), rep(0, u))
  z2 <- cbind(rep(0, u), diag(1 - g[2:(u + 1)]))
  X <- z1 + z2
  
  X

}
