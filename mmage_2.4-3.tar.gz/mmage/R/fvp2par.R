fvp2par <-
function(vp, terminal = "off", method = "steady", lambda = 1, cfec = TRUE) {

	#steady <- TRUE ; lambda <- 1

	z <- vp
  if(nrow(z[z$sex == "M", ]) > 0) bs <- TRUE else bs <- FALSE

  lclass <- z$lclass
	
	Lf <- nrow(z[z$sex == "F",]) - 1
	if(bs) Lm <- nrow(z[z$sex == "M",]) - 1

	# poff/pdea correction for the terminal age class
  u <- Lf + 1
  if(is.finite(lclass[u])) {
    if(terminal == "off")  z$poff[u] <- 1 - z$pdea[u]
    if(terminal == "dea") {z$pdea[u] <- 1 ; z$poff[u] <- 0}
  }
  
  if(bs) {
    u <- Lf + Lm + 2
    if(is.finite(lclass[u])) {
      if(terminal == "off")  z$poff[u] <- 1 - z$pdea[u]
      if(terminal == "dea") {z$pdea[u] <- 1 ; z$poff[u] <- 0}
    }
  }
  
  ptot <- z$pdea + z$poff
  s <- 1 - ptot
  
	# fec
	if(cfec) {
    z$ff <- (1 - ptot / 2) * z$hfecf
    z$fm <- (1 - ptot / 2) * z$hfecm
    if("hpar" %in% names(z)) z$nupar <- (1 - ptot / 2) * z$hpar
	}
  else {
    z$ff <- z$hfecf
    z$fm <- z$hfecm
    if("hpar" %in% names(z)) z$nupar <- z$hpar
  }
	
	# g
  if(method == "steady") z$g <- fg(s = s, lclass = lclass, lambda = lambda)
  if(method == "geom") z$g <- 1 / lclass
  
  nam <- c("sex", "class", "lclass", "cellmin", "cellmax", "nupar", "ff", "fm", "pdea", "poff", "g")

	z[, nam]

	z

}
