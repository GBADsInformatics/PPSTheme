zhh2vh <- function(h, lclass) {

  u <- data.frame(class = 1:length(lclass), lclass = lclass)
  u$a.up <- cumsum(u$lclass)
  u$a.low <- u$a.up - u$lclass
  if(u$lclass[nrow(u)] == Inf) u$a.low[nrow(u)] <- u$a.up[nrow(u) - 1]
  u$A3 <- u$A1 <- 0.5
  u$A2 <- u$a.up - u$a.low - 1
  u$p1 <- u$A1 / u$lclass 
  u$p2 <- u$A2 / u$lclass 
  u$p3 <- u$A3 / u$lclass 
  u <- rbind(c(0, 1, rep(NA, 8)), u)
  u$p3[nrow(u)] <- u$p2[nrow(u)] <- u$p1[nrow(u)] <- NA 
  u$z <- c(h[1], h)
  u$h <- rep(NA, nrow(u))
  u
  
  u$h[1] <- 0.5 * u$z[1] 
  for(i in 2:(nrow(u) - 1))   u$h[i] <- (u$p1[i] + u$p2[i]) * u$z[i] + u$p3[i] * u$z[i + 1]
  u$h[nrow(u)] <- u$z[nrow(u)]   

  u

}