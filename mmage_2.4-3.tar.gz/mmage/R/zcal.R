zcal <-
function(nbphase, nbstep) {

  tim <- 0:(nbstep - 1)
  z <- nbstep / nbphase
  if(!is.integer(z)) z <- trunc(z) + 1
  z <- sort(rep(1:z, nbphase))
  cycle <- z[1:nbstep]
  z <- rep(1:nbphase, max(cycle))
  phase <- z[1:nbstep]
  cal <- data.frame(cycle = cycle, phase = phase, tim = tim, timend = tim + 1) #, tim = tim
  cal
  
  z <- cal
  z$tim <- ifelse(z$phase == 1, z$tim, 0)
  z$nbphase <- rep(1, nrow(z))
  tmp <- aggregate(formula = cbind(tim, nbphase) ~ cycle, data = z, FUN = sum)
  tmp
  
  list(cal = cal, cal.summ = tmp)


}
