fproj2vec <- function(matx, matstru, matini, matend, matdea, matoff, matpar, matb) {
  
  tcla <- matdea[, c("sex", "class", "lclass", "cellmin", "cellmax")]
  tcla2 <- matx[, c("sex", "class", "lclass", "cellmin", "cellmax")]
  
  # vecx
  
  z <- matx
  nam.tim <- grep("t", names(z), value = TRUE)
  z <- as.matrix(z[, nam.tim])
  vec <- zmat2vec(mat = z, tab.aux = tcla2)
  names(vec)[ncol(vec)] <- "x"
  
  z <- matstru
  z <- as.matrix(z[, nam.tim])
  z <- zmat2vec(mat = z, tab.aux = tcla2)
  vec$xstru <- z$z
  row.names(vec) <- 1:nrow(vec)
  
  vecx <- vec
  vecx
  
  # vecprod
  
  z <- matini
  nam.tim <- grep("t", names(z), value = TRUE)
  z <- as.matrix(z[, nam.tim])
  vec <- zmat2vec(mat = z, tab.aux = tcla2)
  names(vec)[ncol(vec)] <- "xini"
  
  z <- matend
  z <- as.matrix(z[, nam.tim])
  z <- zmat2vec(mat = z, tab.aux = tcla2)
  vec$xend <- z$z
  vec$xmean <- (vec$xini + vec$xend) / 2
  vec$delta <- vec$xend - vec$xini
  
  z <- matpar
  z <- as.matrix(z[, nam.tim])
  z <- zmat2vec(mat = z, tab.aux = tcla2)
  vec$par <- z$z

  tab1 <- vec
  tab1
  
  z <- matb
  nam.tim <- grep("t", names(z), value = TRUE)
  z <- as.matrix(z[, nam.tim])
  vec <- zmat2vec(mat = z, tab.aux = tcla)
  names(vec)[ncol(vec)] <- "b"
  
  z <- matdea
  z <- as.matrix(z[, nam.tim])
  z <- zmat2vec(mat = z, tab.aux = tcla)
  vec$dea <- z$z
  
  z <- matoff
  z <- as.matrix(z[, nam.tim])
  z <- zmat2vec(mat = z, tab.aux = tcla)
  vec$off <- z$z
  
  z <- vec
  z <- z[, -match(c("cellmin", "cellmax"), names(z))]
  tab2 <- z
  
  u <- c("sex", "class", "lclass", "tim")
  z <- merge(tab1, tab2, by = u, all = TRUE)
  z$cellmin[is.na(z$cellmin)] <- 0
  z$cellmax[is.na(z$cellmax)] <- 0
  z$par[is.na(z$par)] <- 0
  
  u <- c("tim", "sex", "class", "lclass")
  z <- z[do.call(order, z[, u]), ]
  
  row.names(z) <- 1:nrow(z)
  vecprod <- z
  vecprod
  
	list(vecx = vecx, vecprod = vecprod)   
    
}
