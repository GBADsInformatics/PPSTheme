fnorm <-
function(x) {
  
  foo <- function(x) x / sum(x)
  if(is.vector(x)) x <- foo(x)
  if(is.matrix(x)) x <- apply(x, FUN = foo, MARGIN = 2)
  x 

}
