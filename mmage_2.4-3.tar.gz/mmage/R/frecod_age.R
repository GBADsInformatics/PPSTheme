frecod_age <- function(x, nbphase, type = c("h", "v")) {
  
  u <- x / nbphase
  if(type == "h") x <- trunc(u)
  if(type == "v") x <- ceiling(u) - 1
  x
  
  # example: z <- 0:49 ; data.frame(cell = z, h = frecod_age(z, 12, "h"), v = frecod_age(z, 12, "v"))

}
