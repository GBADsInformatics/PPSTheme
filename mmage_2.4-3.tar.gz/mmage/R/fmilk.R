fmilk <- function(formula, vecprod, wlact, wden = NULL, digits = c(1, 2)) {

  if(length(digits) == 1) digits <- rep(digits, 2)

  z <- vecprod
  #z <- vecprod ; wlact <- rep(135, nrow(z)) ; wden <- NULL ; digits <- c(1, 3)
  
  f <- formula(deparse(formula))
  #f <- formula(~ 1)
  #f <- formula(~ sex)
  #f <- formula(~ sex + group)
  nam.var <- all.vars(f)
  nam.var
  
  nbcycle <- max(z$cycle)
  nbphase <- max(z$phase)
  nbcycle
  nbphase
  
  z[is.na(z)] <- 0
  wlact <- z[, wlact]
  if(length(wden) == 0) wden <- rep(1, nrow(z)) else wden <- z[, wden]
  z$milk <- wlact * z$par
  z$xmean <- wden * z$xmean
  vecprod2 <- z
  head(vecprod2)
  
  newf <- formula(paste("cbind(xmean, milk) ~", f[2]))
  newf

  z <- vecprod2
  z <- aggregate(formula = newf, data = z, FUN = sum)
  if(length(nam.var) > 1)   z <- z[do.call(order, z[, nam.var]), ]
  if("cycle" %in% nam.var) nbc <- 1 else nbc <- nbcycle
  z$xmean <- z$xmean / (nbc * nbphase)
  u <- z$xmean * nbc
  z$rmilk <- z$milk / u
  z$nbcycl <- rep(nbc, nrow(z))
  
  u <- c("xmean", "milk")
  z[, match(u, names(z))] <- round(z[, match(u, names(z))], digits = digits[1])  
  
  u <- c("rmilk")
  z[, match(u, names(z))] <- round(z[, match(u, names(z))], digits = digits[2])
  
  z

}
