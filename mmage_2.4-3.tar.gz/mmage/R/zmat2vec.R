zmat2vec <-
function(mat, tab.aux) {

  # Concatenates vertically the columns of the matrix 'mat' to a single vector
  # and, for each column, add the table 'tab.aux' 
  
  n <- ncol(mat)
	
	z <- zreptab(tab.aux, n)
	z$z <- as.vector(mat)

	row.names(z) <- 1:nrow(z) 

	z
    
}
