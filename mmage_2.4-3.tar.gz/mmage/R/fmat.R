fmat <-
function(param, Lf, Lm) {
	
  z <- param

  FEC <- fmatfec(z, Lf, Lm)

  DEA <- diag(z$pdea)
  OFF <- diag(z$poff)
  ID <- diag(1, nrow(z))

  G <- fmatg(z, Lf, Lm)
  
  A <- G %*% (ID - DEA - OFF) %*% FEC
  
  z$ff <- z$nupar
  z$fm <- rep(0, Lf + Lm + 2)
  PAR <- fmatfec(z, Lf, Lm)

  list(FEC = FEC, DEA = DEA, OFF = OFF, ID = ID, G = G, A = A, PAR = PAR)

}
