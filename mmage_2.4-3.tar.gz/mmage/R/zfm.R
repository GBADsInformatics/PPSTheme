zfm <- function(x) {
  c(x[2:length(x)] / x[1:(length(x) - 1)], NA)
}
