frecod_phase <- function(data, startpha, nbphase) {
  
  j <- startpha
  
  u <- data
  u$zphase <- u$phase - (j - 1)
  u$zcycle <- ifelse(u$zphase <= 0, u$cycle - 1, u$cycle)
  u$zphase[u$zphase <= 0] <- u$zphase[u$zphase <= 0] + nbphase
  
  u$cycle <- as.integer(u$zcycle)
  u$phase <- as.integer(u$zphase)
  
  u <- u[, -match(c("zcycle", "zphase"), names(u))]
  
  u
}



