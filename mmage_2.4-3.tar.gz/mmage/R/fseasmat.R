fseasmat <-
function(param, phase.ini = 1) {
  
  z <- param
  nbphase <- length(z)
  if(phase.ini == 1) u <- 1:nbphase else u <- c(phase.ini:nbphase, 1:(phase.ini - 1))
  z <- z[u]
  
  B <- vector("list", nbphase)
  for(i in 1:nbphase) {
    B[[i]] <- fmat(z[[i]])$A
    if(i == 1) A <- B[[i]] else A <- B[[i]] %*% A
  }
  names(B) <- names(z)
  
  list(A = A, B = B, param = z, phase = u)

}
