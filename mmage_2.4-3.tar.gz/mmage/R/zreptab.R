zreptab <-
function(tab, n) {
	
  # Vertical concatenation of n tables 'tab'.
  # An index tim (going from 0 to n - 1) is added to each replicate.
  
  z <- c(tab)
  z <- lapply(z, FUN = rep, times = n)	
  z <- as.data.frame(z)
  z$tim <- sort(rep(0:(n - 1), nrow(tab)))
  z

}


