fvh2par <-
function(vh, terminal = "off", method = "steady", lambda = 1, correctionfec = TRUE) {

	#steady <- TRUE ; lambda <- 1

	z <- vh
	Lf <- length(z$sex[z$sex == "F"]) - 1
  u <- length(z$sex[z$sex == "M"])
  if(u > 0) Lm <- u - 1 else Lm <- 0

  lclass <- z$lclass
	
	# pdea and poff
  z$htot <- z$hdea + z$hoff
  z$htot <- ifelse(z$htot == 0, 1e-10, z$htot)
  z$pdea <- (z$hdea / z$htot) * (1 - exp(-z$htot))
  z$poff <- (z$hoff / z$htot) * (1 - exp(-z$htot))
  # warning: if htot is highly negative (htot < -.10), poff.h under-estimates poff.direct

	# poff & pdea correction for the terminal age class
  u <- Lf + 1
  if(is.finite(lclass[u])) {
    if(terminal == "off")  z$poff[u] <- 1 - z$pdea[u]
    if(terminal == "dea") {z$pdea[u] <- 1 ; z$poff[u] <- 0}
  }
  
  if(Lm > 0) {
    u <- Lf + Lm + 2
    if(is.finite(lclass[u])) {
      if(terminal == "off")  z$poff[u] <- 1 - z$pdea[u]
      if(terminal == "dea") {z$pdea[u] <- 1 ; z$poff[u] <- 0}
    }
  }
  
  ptot <- z$pdea + z$poff
  s <- 1 - ptot
  
	# fec
	if(correctionfec) {
    z$ff <- (1 - ptot / 2) * z$hfecf
    z$fm <- (1 - ptot / 2) * z$hfecm
    z$nupar <- (1 - ptot / 2) * z$hpar
	}
  else {
    z$ff <- z$hfecf
    z$fm <- z$hfecm
    z$nupar <- z$hpar
  }
	
	# g
  if(method == "steady") z$g <- fg(s = s, lclass = lclass, lambda = lambda)
  if(method == "geom") z$g <- 1 / lclass
  
  nam <- c("sex", "class", "lclass", "cellmin", "cellmax", "nupar", "ff", "fm", "pdea", "poff", "g")

	z[, nam]

}
