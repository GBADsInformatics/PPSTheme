fmatfec <-
function(param, Lf, Lm) {

  L <- Lf + Lm
  
  fecf <- param$ff[2:(Lf + 1)]
  fecm <- param$fm[2:(Lf + 1)]
  
  X1 <- rbind(fecf, diag(1, Lf))
  X2 <- matrix(0, nrow = Lf + 1, ncol = Lm)
  X3 <- matrix(0, nrow = Lm + 1, ncol = Lf)
  X3[1, ] <- fecm
  X4 <- rbind(rep(0, Lm), diag(1, Lm))
  X <- rbind(cbind(X1, X2), cbind(X3, X4))  
  
  #X <- matrix(0, nrow = L + 2, ncol = L)
  #X[1, 1:Lf] <- fecf
  #X[Lf + 2, 1:Lf] <- fecm
  
  #diag(X[2:(Lf + 1), ]) <- 1
  #diag(X[(Lf + 3):(Lf + Lm + 2), (Lf + 1):(Lf + Lm)]) <- 1

  #X[2:(Lf + 1), ][seq(1, (Lf * Lf), by = Lf + 1)] <- 1
  #X[(Lf + 3):(Lf + Lm + 2), (Lf + 1):(Lf + Lm)][seq(1, (Lm * Lm), by = Lm + 1)] <- 1
  
  X

}


