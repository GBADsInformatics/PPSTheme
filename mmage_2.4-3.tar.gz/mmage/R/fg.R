fg <-
function(s, lclass, lambda = 1) {
  
  s <- ifelse(s < 0, 0, ifelse(s > 1, 1, s))
  s <- s / lambda
  s <- ifelse(s == 1, 1 - 1e-10, s)
  g <- (s^(lclass - 1) - s^lclass) / (1 - s^lclass)
  
  g

}
