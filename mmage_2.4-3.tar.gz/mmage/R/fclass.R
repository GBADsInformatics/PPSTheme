fclass <-
function(lclassf, lclassm = NULL, inf = TRUE) {
  
	sex <- "F"
	lclass <- lclassf
  if(!(lclass[length(lclass)] %in% c(1, Inf)))
    stop("\n\nThe length of the terminal age class in lclassf should be either 1 or Inf.\n\n")
	nbclass <- length(lclass)
	u <- data.frame(sex = rep(sex, nbclass + 1), class = 0:nbclass)
	u$lclass <- c(1, lclass)
	z <- u

  Lm <- length(lclassm)  
	if(Lm > 0) {
    sex <- "M"
    lclass <- lclassm
    if(!(lclass[length(lclass)] %in% c(1, Inf)))
      stop("\n\nThe length of the terminal age class in lclassm should be either 1 or Inf.\n\n")
    nbclass <- length(lclass)
    u <- data.frame(sex = rep(sex, nbclass + 1), class = 0:nbclass)
	  u$lclass <- c(1, lclass)
    z <- rbind(z, u)
	}
  
  z$cellmax <- z$cellmin <- rep(0, nrow(z))
  for(i in 2:nrow(z)) {
    z$cellmin[i] <- z$cellmax[i - 1] + 1
    z$cellmax[i] <- z$cellmin[i] + z$lclass[i] - 1
    if(z$class[i] == 0) z$cellmax[i] <- z$cellmin[i] <- 0
  }
  
  #if(inf) {
  #  z$cellmax[z$sex == "F" & z$class == max(z$class[z$sex == "F"])] <- Inf
  #  z$cellmax[z$sex == "M" & z$class == max(z$class[z$sex == "M"])] <- Inf
  #}
  
	z
}
