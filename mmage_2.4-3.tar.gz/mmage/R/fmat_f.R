fmat_f <-
function(param, Lf) {
	
  z <- param

  FEC <- fmatfec_f(z, Lf)

  DEA <- diag(z$pdea)
  OFF <- diag(z$poff)
  ID <- diag(1, nrow(z))

  G <- fmatg_f(z, Lf)
  
  A <- G %*% (ID - DEA - OFF) %*% FEC
  
  z$ff <- z$nupar
  PAR <- fmatfec_f(z, Lf)

  list(FEC = FEC, DEA = DEA, OFF = OFF, ID = ID, G = G, A = A, PAR = PAR)

}
